# Flash — Supabase setup guide

## 1. Create project
https://supabase.com → New project

## 2. Run database schema
SQL Editor → New query → paste entire `supabase/schema.sql` → Run

## 3. Create storage buckets
Dashboard → **Storage** → New bucket:

| Bucket       | Public |
|--------------|--------|
| `videos`     | Yes    |
| `thumbnails` | Yes    |

### Storage policies (Storage → videos → Policies)

**Select** — allow public read:
```sql
bucket_id = 'videos'
```

**Insert** — authenticated users, own folder only:
```sql
bucket_id = 'videos' AND auth.uid()::text = (storage.foldername(name))[1]
```

**Delete** — own files:
```sql
bucket_id = 'videos' AND auth.uid()::text = (storage.foldername(name))[1]
```

Repeat similar policies for `thumbnails` if you use it.

## 4. Environment variables
```bash
cp .env.example .env.local
```

```env
NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

## 5. Run the app
```bash
npm install
npm run dev
```

## 6. Verify
1. Open app → Log in with **Email** (sign up)
2. Create → upload a short video
3. Check Storage → `videos` bucket for the file
4. Check Table Editor → `videos` for the row

## Demo mode
If `.env.local` is missing, Flash runs fully in the browser with mock data. No Supabase required.
