# Flash — Share moments that matter

Short-form video sharing app (TikTok / Reels style).

**Ready to publish** — see [PUBLISH.md](./PUBLISH.md) for Vercel steps.

## Features

- Vertical feed (For You / Following), autoplay, progress bar
- Double-tap like, comments, share, save, report
- Upload with auto-thumbnail + Supabase Storage
- Explore, hashtags, profile, inbox, settings
- Demo auth **or** real Supabase email auth
- Onboarding, toasts, PWA manifest

## Quick start

```bash
cd flash
npm install
npm run dev
```

Open http://localhost:3000

## Publish

```bash
npm run build   # must succeed
# then follow PUBLISH.md → GitHub + Vercel
```

Demo mode needs **no** API keys.  
Real accounts/videos: see [SETUP.md](./SETUP.md).

## Stack

- Next.js 15 + TypeScript + Tailwind 4
- Supabase (optional): Auth, Postgres, Storage
- lucide-react

## License

MIT
