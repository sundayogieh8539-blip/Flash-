# Publish Flash to the internet

You can publish in **demo mode** (no backend) in under 10 minutes, or with **Supabase** for real accounts and uploads.

---

## Option A — Publish demo (fastest)

Works with mock data. No Supabase needed.

### 1. Install & test locally

```bash
cd flash
npm install
npm run build
npm run dev
```

Open http://localhost:3000 and click around.

### 2. Push to GitHub

```bash
cd flash
git init
git add .
git commit -m "Flash app — ready to publish"
# Create a new empty repo on GitHub, then:
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/flash.git
git push -u origin main
```

### 3. Deploy on Vercel

1. Go to https://vercel.com → **Add New Project**
2. Import your `flash` GitHub repo
3. Framework: **Next.js** (auto-detected)
4. Click **Deploy**
5. Done — you get a URL like `https://flash-xxx.vercel.app`

No environment variables required for demo mode.

---

## Option B — Publish with real auth + videos (Supabase)

### 1. Supabase

1. Create project at https://supabase.com  
2. SQL Editor → run `supabase/schema.sql`  
3. Storage → create public buckets: `videos`, `thumbnails`  
4. Add storage policies (see SETUP.md)  
5. Copy **Project URL** and **anon key**

### 2. Local env

```bash
cp .env.example .env.local
```

```env
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

```bash
npm install
npm run build
```

### 3. Vercel env vars

In Vercel → Project → Settings → Environment Variables:

| Name | Value |
|------|--------|
| `NEXT_PUBLIC_SUPABASE_URL` | your Supabase URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | your anon key |
| `NEXT_PUBLIC_APP_URL` | `https://your-app.vercel.app` |

Redeploy after saving env vars.

### 4. Supabase Auth URL config

Supabase → Authentication → URL Configuration:

- Site URL: `https://your-app.vercel.app`
- Redirect URLs: `https://your-app.vercel.app/**`

---

## Custom domain (optional)

Vercel → Project → Settings → Domains → add `flash.yourdomain.com`

Update `NEXT_PUBLIC_APP_URL` and Supabase Site URL to match.

---

## Checklist before sharing publicly

- [ ] `npm run build` succeeds locally
- [ ] Landing + feed + upload work on mobile browser
- [ ] (If Supabase) Sign up / login works
- [ ] (If Supabase) Upload a short test video
- [ ] Privacy / terms links (add when you have a company)
- [ ] Content moderation plan for user uploads

---

## After publish

Share your Vercel URL. Users can:

- Browse the feed (demo videos always available)
- Log in with demo accounts or real email (if Supabase is set)
- Upload videos (stored in Supabase when configured)

For production scale later: add Cloudflare Stream/Mux, ranking, and moderation.
