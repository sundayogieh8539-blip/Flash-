-- Flash production schema (run in Supabase SQL editor)

-- Profiles (extends auth.users)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  display_name text not null,
  avatar_url text,
  bio text default '',
  verified boolean default false,
  created_at timestamptz default now()
);

-- Videos
create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  description text default '',
  hashtags text[] default '{}',
  storage_path text,
  stream_url text,
  thumbnail_url text,
  duration_sec int,
  views bigint default 0,
  likes_count bigint default 0,
  comments_count bigint default 0,
  shares_count bigint default 0,
  status text default 'processing' check (status in ('processing', 'ready', 'rejected')),
  created_at timestamptz default now()
);

create index if not exists videos_user_id_idx on public.videos(user_id);
create index if not exists videos_created_at_idx on public.videos(created_at desc);
create index if not exists videos_status_idx on public.videos(status);

-- Follows
create table if not exists public.follows (
  follower_id uuid references public.profiles(id) on delete cascade,
  following_id uuid references public.profiles(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (follower_id, following_id)
);

-- Likes
create table if not exists public.likes (
  user_id uuid references public.profiles(id) on delete cascade,
  video_id uuid references public.videos(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (user_id, video_id)
);

-- Comments
create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  video_id uuid not null references public.videos(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  parent_id uuid references public.comments(id) on delete cascade,
  text text not null,
  likes_count int default 0,
  created_at timestamptz default now()
);

create index if not exists comments_video_id_idx on public.comments(video_id);

-- Auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, username, display_name, avatar_url)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'username', split_part(new.email, '@', 1)),
    coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1)),
    new.raw_user_meta_data->>'avatar_url'
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- RLS
alter table public.profiles enable row level security;
alter table public.videos enable row level security;
alter table public.follows enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;

-- Profiles: public read, own update
create policy "Profiles are viewable by everyone"
  on public.profiles for select using (true);
create policy "Users can update own profile"
  on public.profiles for update using (auth.uid() = id);

-- Videos: public read ready, own insert/update
create policy "Ready videos are viewable by everyone"
  on public.videos for select using (status = 'ready' or auth.uid() = user_id);
create policy "Users can insert own videos"
  on public.videos for insert with check (auth.uid() = user_id);
create policy "Users can update own videos"
  on public.videos for update using (auth.uid() = user_id);

-- Follows
create policy "Follows are viewable by everyone"
  on public.follows for select using (true);
create policy "Users can follow"
  on public.follows for insert with check (auth.uid() = follower_id);
create policy "Users can unfollow"
  on public.follows for delete using (auth.uid() = follower_id);

-- Likes
create policy "Likes are viewable by everyone"
  on public.likes for select using (true);
create policy "Users can like"
  on public.likes for insert with check (auth.uid() = user_id);
create policy "Users can unlike"
  on public.likes for delete using (auth.uid() = user_id);

-- Comments
create policy "Comments are viewable by everyone"
  on public.comments for select using (true);
create policy "Users can comment"
  on public.comments for insert with check (auth.uid() = user_id);
create policy "Users can delete own comments"
  on public.comments for delete using (auth.uid() = user_id);

-- ============================================================
-- STORAGE SETUP (run after schema, or use Dashboard → Storage)
-- ============================================================
-- 1. Create a public bucket named: videos
-- 2. Create a public bucket named: thumbnails (optional)
--
-- Storage policies (SQL):

-- Allow authenticated users to upload to their own folder
-- insert into storage.buckets (id, name, public) values ('videos', 'videos', true)
--   on conflict (id) do nothing;
-- insert into storage.buckets (id, name, public) values ('thumbnails', 'thumbnails', true)
--   on conflict (id) do nothing;

-- Policies for videos bucket:
-- CREATE POLICY "Anyone can view videos"
--   ON storage.objects FOR SELECT
--   USING (bucket_id = 'videos');
--
-- CREATE POLICY "Users can upload own videos"
--   ON storage.objects FOR INSERT
--   WITH CHECK (
--     bucket_id = 'videos'
--     AND auth.uid()::text = (storage.foldername(name))[1]
--   );
--
-- CREATE POLICY "Users can delete own videos"
--   ON storage.objects FOR DELETE
--   USING (
--     bucket_id = 'videos'
--     AND auth.uid()::text = (storage.foldername(name))[1]
--   );
