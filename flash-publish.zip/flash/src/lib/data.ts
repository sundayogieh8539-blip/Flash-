export interface User {
  id: string;
  username: string;
  displayName: string;
  avatar: string;
  bio: string;
  followers: number;
  following: number;
  likes: number;
  verified?: boolean;
}

export interface Video {
  id: string;
  userId: string;
  title: string;
  description: string;
  hashtags: string[];
  thumbnail: string;
  videoUrl: string;
  likes: number;
  comments: number;
  shares: number;
  views: number;
  createdAt: Date;
  duration: number; // seconds
}

export interface Comment {
  id: string;
  videoId: string;
  userId: string;
  text: string;
  likes: number;
  createdAt: Date;
}

export const users: User[] = [
  {
    id: "u1",
    username: "maya.creates",
    displayName: "Maya Chen",
    avatar: "https://api.dicebear.com/9.x/avataaars/svg?seed=Maya",
    bio: "Daily vlogs & creative tips ✨ | SF",
    followers: 128400,
    following: 312,
    likes: 2400000,
    verified: true,
  },
  {
    id: "u2",
    username: "jordan.moves",
    displayName: "Jordan Lee",
    avatar: "https://api.dicebear.com/9.x/avataaars/svg?seed=Jordan",
    bio: "Dance • Fitness • Good vibes only",
    followers: 89200,
    following: 189,
    likes: 1100000,
  },
  {
    id: "u3",
    username: "tech.with.sam",
    displayName: "Sam Rivera",
    avatar: "https://api.dicebear.com/9.x/avataaars/svg?seed=Sam",
    bio: "Tech reviews that actually help 🛠️",
    followers: 256000,
    following: 94,
    likes: 3800000,
    verified: true,
  },
  {
    id: "u4",
    username: "luna.eats",
    displayName: "Luna Park",
    avatar: "https://api.dicebear.com/9.x/avataaars/svg?seed=Luna",
    bio: "Street food hunter 🍜 | NYC",
    followers: 67400,
    following: 421,
    likes: 890000,
  },
  {
    id: "u5",
    username: "alex.codes",
    displayName: "Alex Kim",
    avatar: "https://api.dicebear.com/9.x/avataaars/svg?seed=Alex",
    bio: "Building in public • Full-stack",
    followers: 45200,
    following: 267,
    likes: 520000,
  },
];

export const videos: Video[] = [
  {
    id: "v1",
    userId: "u1",
    title: "Golden hour in the city",
    description: "Nothing beats this light. Shot on my phone 📱✨",
    hashtags: ["goldenhour", "citylife", "cinematography", "vibes"],
    thumbnail: "https://images.unsplash.com/photo-1514565131-fce0801e5785?w=400&h=700&fit=crop",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    likes: 48200,
    comments: 1240,
    shares: 3200,
    views: 890000,
    createdAt: new Date(Date.now() - 1000 * 60 * 45),
    duration: 15,
  },
  {
    id: "v2",
    userId: "u2",
    title: "30-second core burner",
    description: "No equipment needed. Do this every morning!",
    hashtags: ["fitness", "core", "workout", "homeworkout"],
    thumbnail: "https://images.unsplash.com/photo-1518611012118-696072aa579a?w=400&h=700&fit=crop",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
    likes: 92100,
    comments: 3400,
    shares: 8700,
    views: 2100000,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 3),
    duration: 32,
  },
  {
    id: "v3",
    userId: "u3",
    title: "This AI tool changed my workflow",
    description: "Honest review after 2 weeks of daily use. Link in bio.",
    hashtags: ["ai", "productivity", "techreview", "tools"],
    thumbnail: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=400&h=700&fit=crop",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
    likes: 156000,
    comments: 8900,
    shares: 21000,
    views: 4200000,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 8),
    duration: 48,
  },
  {
    id: "v4",
    userId: "u4",
    title: "Best $4 taco in the city?",
    description: "Hidden gem alert 🚨 You have to try this place",
    hashtags: ["streetfood", "tacos", "foodie", "nyc"],
    thumbnail: "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=400&h=700&fit=crop",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
    likes: 33400,
    comments: 980,
    shares: 2100,
    views: 670000,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 12),
    duration: 22,
  },
  {
    id: "v5",
    userId: "u5",
    title: "I built a full app in one weekend",
    description: "Here's the entire process + tech stack I used",
    hashtags: ["coding", "buildinpublic", "webdev", "nextjs"],
    thumbnail: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=400&h=700&fit=crop",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4",
    likes: 67800,
    comments: 2100,
    shares: 5400,
    views: 1100000,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 20),
    duration: 58,
  },
  {
    id: "v6",
    userId: "u1",
    title: "Morning routine that actually works",
    description: "Simple, sustainable, no 5am nonsense",
    hashtags: ["morningroutine", "productivity", "lifestyle"],
    thumbnail: "https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=400&h=700&fit=crop",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
    likes: 41200,
    comments: 1560,
    shares: 2800,
    views: 780000,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 26),
    duration: 41,
  },
];

export const comments: Comment[] = [
  {
    id: "c1",
    videoId: "v1",
    userId: "u2",
    text: "This lighting is unreal 🔥",
    likes: 234,
    createdAt: new Date(Date.now() - 1000 * 60 * 20),
  },
  {
    id: "c2",
    videoId: "v1",
    userId: "u3",
    text: "What camera settings did you use?",
    likes: 89,
    createdAt: new Date(Date.now() - 1000 * 60 * 15),
  },
  {
    id: "c3",
    videoId: "v2",
    userId: "u1",
    text: "Doing this every day now. Legs are on fire 😅",
    likes: 512,
    createdAt: new Date(Date.now() - 1000 * 60 * 60),
  },
  {
    id: "c4",
    videoId: "v3",
    userId: "u5",
    text: "Just tried it. Game changer for research.",
    likes: 1203,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2),
  },
];

export function getUser(id: string): User | undefined {
  return users.find((u) => u.id === id);
}

export function getVideo(id: string): Video | undefined {
  return videos.find((v) => v.id === id);
}

export function getVideosByUser(userId: string): Video[] {
  return videos.filter((v) => v.userId === userId);
}

export function getCommentsForVideo(videoId: string): Comment[] {
  return comments.filter((c) => c.videoId === videoId);
}
