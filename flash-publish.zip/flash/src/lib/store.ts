"use client";

import { createClient, isSupabaseConfigured } from "@/lib/supabase/client";

export function getJSON<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function setJSON(key: string, value: unknown) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // ignore
  }
}

export function getFollows(): string[] {
  return getJSON<string[]>("flash_follows", []);
}

export function toggleFollow(userId: string, currentUserId?: string): boolean {
  const follows = getFollows();
  const idx = follows.indexOf(userId);
  let nowFollowing: boolean;

  if (idx >= 0) {
    follows.splice(idx, 1);
    nowFollowing = false;
  } else {
    follows.push(userId);
    nowFollowing = true;
  }
  setJSON("flash_follows", follows);

  // Sync to Supabase when configured
  if (isSupabaseConfigured() && currentUserId) {
    const supabase = createClient();
    if (supabase) {
      if (nowFollowing) {
        supabase.from("follows").insert({
          follower_id: currentUserId,
          following_id: userId,
        }).then(() => {});
      } else {
        supabase
          .from("follows")
          .delete()
          .eq("follower_id", currentUserId)
          .eq("following_id", userId)
          .then(() => {});
      }
    }
  }

  return nowFollowing;
}

export function isFollowing(userId: string): boolean {
  return getFollows().includes(userId);
}

export function getLikes(): Record<string, boolean> {
  return getJSON<Record<string, boolean>>("flash_likes", {});
}

export function toggleLikeStore(videoId: string): boolean {
  const likes = getLikes();
  if (likes[videoId]) {
    delete likes[videoId];
    setJSON("flash_likes", likes);
    return false;
  }
  likes[videoId] = true;
  setJSON("flash_likes", likes);
  return true;
}

export function getSaves(): string[] {
  return getJSON<string[]>("flash_saves", []);
}

export function toggleSaveStore(videoId: string): boolean {
  const saves = getSaves();
  const idx = saves.indexOf(videoId);
  if (idx >= 0) {
    saves.splice(idx, 1);
    setJSON("flash_saves", saves);
    return false;
  }
  saves.push(videoId);
  setJSON("flash_saves", saves);
  return true;
}

export function hasSeenOnboarding(): boolean {
  return getJSON("flash_onboarding_done", false);
}

export function markOnboardingDone() {
  setJSON("flash_onboarding_done", true);
}
