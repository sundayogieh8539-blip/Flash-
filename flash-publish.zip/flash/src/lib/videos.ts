import { videos as mockVideos, Video, getUser, users } from "@/lib/data";
import { createClient, isSupabaseConfigured } from "@/lib/supabase/client";

export type { Video };

function mapRow(row: Record<string, unknown>): Video {
  return {
    id: String(row.id),
    userId: String(row.user_id),
    title: String(row.title || ""),
    description: String(row.description || ""),
    hashtags: (row.hashtags as string[]) || [],
    thumbnail: String(row.thumbnail_url || ""),
    videoUrl: String(row.stream_url || row.storage_path || ""),
    likes: Number(row.likes_count || 0),
    comments: Number(row.comments_count || 0),
    shares: Number(row.shares_count || 0),
    views: Number(row.views || 0),
    createdAt: new Date(String(row.created_at || Date.now())),
    duration: Number(row.duration_sec || 0),
  };
}

/** Fetch feed videos — Supabase when configured, else mock */
export async function fetchFeedVideos(options?: {
  followingIds?: string[];
}): Promise<Video[]> {
  if (!isSupabaseConfigured()) {
    if (options?.followingIds?.length) {
      return mockVideos.filter((v) => options.followingIds!.includes(v.userId));
    }
    return mockVideos;
  }

  const supabase = createClient();
  if (!supabase) return mockVideos;

  let query = supabase
    .from("videos")
    .select("*")
    .eq("status", "ready")
    .order("created_at", { ascending: false })
    .limit(50);

  if (options?.followingIds?.length) {
    query = query.in("user_id", options.followingIds);
  }

  const { data, error } = await query;
  if (error || !data?.length) {
    // Fallback to mock so the UI is never empty during setup
    return mockVideos;
  }
  return data.map(mapRow);
}

/** Create a video record (metadata). File upload to storage comes later. */
export async function createVideo(input: {
  userId: string;
  title: string;
  description: string;
  hashtags: string[];
  thumbnailUrl?: string;
  streamUrl?: string;
  storagePath?: string;
  duration?: number;
}): Promise<{ data?: Video; error?: string }> {
  if (!isSupabaseConfigured()) {
    // Demo: persist to localStorage
    try {
      const stored = JSON.parse(localStorage.getItem("flash_uploads") || "[]");
      const local: Video = {
        id: `local-${Date.now()}`,
        userId: input.userId,
        title: input.title,
        description: input.description,
        hashtags: input.hashtags,
        thumbnail: input.thumbnailUrl || "",
        videoUrl: input.streamUrl || "",
        likes: 0,
        comments: 0,
        shares: 0,
        views: 0,
        createdAt: new Date(),
        duration: input.duration || 0,
      };
      stored.unshift(local);
      localStorage.setItem("flash_uploads", JSON.stringify(stored.slice(0, 20)));
      return { data: local };
    } catch {
      return { error: "Could not save locally" };
    }
  }

  const supabase = createClient();
  if (!supabase) return { error: "Supabase not configured" };

  const { data, error } = await supabase
    .from("videos")
    .insert({
      user_id: input.userId,
      title: input.title,
      description: input.description,
      hashtags: input.hashtags,
      thumbnail_url: input.thumbnailUrl,
      stream_url: input.streamUrl,
      storage_path: input.storagePath,
      duration_sec: input.duration,
      status: "ready", // until real processing pipeline exists
    })
    .select()
    .single();

  if (error) return { error: error.message };
  return { data: mapRow(data) };
}

export async function toggleLikeDb(
  videoId: string,
  userId: string,
  currentlyLiked: boolean
): Promise<{ error?: string }> {
  if (!isSupabaseConfigured()) return {};

  const supabase = createClient();
  if (!supabase) return {};

  if (currentlyLiked) {
    const { error } = await supabase
      .from("likes")
      .delete()
      .eq("video_id", videoId)
      .eq("user_id", userId);
    if (error) return { error: error.message };
  } else {
    const { error } = await supabase.from("likes").insert({
      video_id: videoId,
      user_id: userId,
    });
    if (error) return { error: error.message };
  }
  return {};
}

export async function fetchFollowingIds(userId: string): Promise<string[]> {
  if (!isSupabaseConfigured()) {
    try {
      return JSON.parse(localStorage.getItem("flash_follows") || "[]");
    } catch {
      return [];
    }
  }

  const supabase = createClient();
  if (!supabase) return [];

  const { data } = await supabase
    .from("follows")
    .select("following_id")
    .eq("follower_id", userId);

  return (data || []).map((r) => r.following_id as string);
}

export { getUser, users };
