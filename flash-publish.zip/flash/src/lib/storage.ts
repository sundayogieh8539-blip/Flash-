import { createClient, isSupabaseConfigured } from "@/lib/supabase/client";

const BUCKET = "videos";

/**
 * Upload a video file to Supabase Storage.
 * Returns public URL + storage path, or a local blob URL in demo mode.
 */
export async function uploadVideoFile(
  file: File,
  userId: string
): Promise<{ url: string; path: string; error?: string }> {
  // Demo mode: use local object URL (not persisted on server)
  if (!isSupabaseConfigured()) {
    const url = URL.createObjectURL(file);
    return { url, path: `local/${userId}/${file.name}` };
  }

  const supabase = createClient();
  if (!supabase) {
    return { url: "", path: "", error: "Supabase not configured" };
  }

  const ext = file.name.split(".").pop() || "mp4";
  const path = `${userId}/${Date.now()}.${ext}`;

  const { error } = await supabase.storage.from(BUCKET).upload(path, file, {
    cacheControl: "3600",
    upsert: false,
    contentType: file.type || "video/mp4",
  });

  if (error) {
    return { url: "", path: "", error: error.message };
  }

  const { data } = supabase.storage.from(BUCKET).getPublicUrl(path);

  return {
    url: data.publicUrl,
    path,
  };
}

/**
 * Optional: upload a thumbnail image later
 */
export async function uploadThumbnail(
  file: Blob,
  userId: string,
  videoId: string
): Promise<{ url: string; error?: string }> {
  if (!isSupabaseConfigured()) {
    return { url: URL.createObjectURL(file) };
  }

  const supabase = createClient();
  if (!supabase) return { url: "", error: "Supabase not configured" };

  const path = `${userId}/thumbs/${videoId}.jpg`;
  const { error } = await supabase.storage.from("thumbnails").upload(path, file, {
    contentType: "image/jpeg",
    upsert: true,
  });

  if (error) return { url: "", error: error.message };

  const { data } = supabase.storage.from("thumbnails").getPublicUrl(path);
  return { url: data.publicUrl };
}
