"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { Play, Zap, Users, TrendingUp, ArrowRight } from "lucide-react";
import { useAuth } from "@/context/AuthContext";

export default function LandingPage() {
  const { isLoggedIn, login } = useAuth();
  const router = useRouter();

  const handleGetStarted = () => {
    if (!isLoggedIn) login();
    router.push("/feed");
  };

  return (
    <div className="min-h-dvh bg-background text-foreground">
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-accent/15 via-transparent to-transparent" />
        <nav className="relative z-10 mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-accent">
              <Zap size={20} className="fill-white text-white" />
            </div>
            <span className="text-xl font-bold tracking-tight text-accent">
              Flash
            </span>
          </div>
          <div className="flex items-center gap-3">
            {isLoggedIn ? (
              <Link
                href="/feed"
                className="rounded-full bg-accent px-5 py-2 text-sm font-semibold text-white transition hover:bg-accent-hover"
              >
                Open app
              </Link>
            ) : (
              <>
                <button
                  onClick={() => {
                    login();
                    router.push("/feed");
                  }}
                  className="rounded-full px-4 py-2 text-sm font-medium text-muted transition hover:text-foreground"
                >
                  Log in
                </button>
                <button
                  onClick={handleGetStarted}
                  className="rounded-full bg-accent px-5 py-2 text-sm font-semibold text-white transition hover:bg-accent-hover"
                >
                  Get started
                </button>
              </>
            )}
          </div>
        </nav>

        <div className="relative z-10 mx-auto max-w-4xl px-6 pb-24 pt-16 text-center">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-1.5 text-sm text-muted">
            <span className="h-2 w-2 rounded-full bg-accent animate-pulse" />
            Now in open beta
          </div>
          <h1 className="mb-6 text-5xl font-extrabold leading-[1.1] tracking-tight text-foreground sm:text-6xl md:text-7xl">
            Share moments
            <br />
            <span className="gradient-text">that matter</span>
          </h1>
          <p className="mx-auto mb-10 max-w-xl text-lg text-muted">
            Flash is the fastest way to create, discover, and share short
            videos. Join creators already lighting up the feed.
          </p>
          <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
            <button
              onClick={handleGetStarted}
              className="group flex items-center gap-2 rounded-full bg-accent px-8 py-3.5 text-base font-semibold text-white transition hover:bg-accent-hover"
            >
              <Play size={20} className="fill-white" />
              Open the feed
              <ArrowRight
                size={18}
                className="transition group-hover:translate-x-1"
              />
            </button>
            <Link
              href="/upload"
              className="rounded-full border-2 border-accent bg-white px-8 py-3.5 text-base font-semibold text-accent transition hover:bg-card"
            >
              Create a Flash
            </Link>
          </div>
        </div>
      </header>

      <section className="border-t border-border bg-card/50 py-20">
        <div className="mx-auto max-w-6xl px-6">
          <h2 className="mb-12 text-center text-3xl font-bold text-foreground">
            Built for creators
          </h2>
          <div className="grid gap-8 sm:grid-cols-3">
            {[
              {
                icon: Zap,
                title: "Instant share",
                desc: "Record or upload and post in seconds. No complicated editors required.",
              },
              {
                icon: TrendingUp,
                title: "Real reach",
                desc: "Smart discovery puts your content in front of people who will love it.",
              },
              {
                icon: Users,
                title: "Real community",
                desc: "Follow, comment, collaborate. Build an audience that actually engages.",
              },
            ].map(({ icon: Icon, title, desc }) => (
              <div
                key={title}
                className="rounded-2xl border border-border bg-white p-6 shadow-sm transition hover:border-accent/40 hover:shadow-md"
              >
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-accent/10">
                  <Icon size={24} className="text-accent" />
                </div>
                <h3 className="mb-2 text-lg font-semibold">{title}</h3>
                <p className="text-sm leading-relaxed text-muted">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="mx-auto max-w-3xl px-6 text-center">
          <h2 className="mb-4 text-3xl font-bold">Ready to go viral?</h2>
          <p className="mb-8 text-muted">
            Create your first Flash in under a minute. No credit card. No
            waitlist.
          </p>
          <button
            onClick={handleGetStarted}
            className="inline-flex items-center gap-2 rounded-full bg-accent px-8 py-3.5 text-base font-semibold text-white transition hover:bg-accent-hover"
          >
            Start creating
            <ArrowRight size={18} />
          </button>
        </div>
      </section>

      <footer className="border-t border-border bg-card py-8">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-6 sm:flex-row">
          <div className="flex items-center gap-2">
            <Zap size={16} className="text-accent" />
            <span className="text-sm font-semibold text-accent">Flash</span>
          </div>
          <p className="text-xs text-muted">
            © {new Date().getFullYear()} Flash. Built for creators.
          </p>
        </div>
      </footer>
    </div>
  );
}
