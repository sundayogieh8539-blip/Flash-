"use client";

import { useState, useRef } from "react";
import { useRouter } from "next/navigation";
import {
  Upload,
  X,
  Image as ImageIcon,
  Hash,
  Check,
  Loader2,
} from "lucide-react";
import BottomNav from "@/components/BottomNav";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/context/ToastContext";
import { createVideo } from "@/lib/videos";
import { uploadVideoFile, uploadThumbnail } from "@/lib/storage";
import { captureThumbnail } from "@/lib/thumbnail";
import { cn } from "@/lib/utils";

export default function UploadPage() {
  const router = useRouter();
  const { isLoggedIn, login, user } = useAuth();
  const { toast } = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [thumbPreview, setThumbPreview] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [hashtags, setHashtags] = useState("");
  const [uploading, setUploading] = useState(false);
  const [progressLabel, setProgressLabel] = useState("");
  const [done, setDone] = useState(false);

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (!f.type.startsWith("video/")) {
      toast("Please select a video file", "error");
      return;
    }
    if (f.size > 100 * 1024 * 1024) {
      toast("Video must be under 100MB", "error");
      return;
    }
    setFile(f);
    setPreview(URL.createObjectURL(f));

    // Generate thumbnail preview
    const blob = await captureThumbnail(f);
    if (blob) {
      setThumbPreview(URL.createObjectURL(blob));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;

    if (!isLoggedIn) {
      login();
    }

    const userId = user?.id || "u1";
    setUploading(true);

    try {
      setProgressLabel("Uploading video...");
      const uploaded = await uploadVideoFile(file, userId);
      if (uploaded.error) {
        toast(uploaded.error, "error");
        setUploading(false);
        setProgressLabel("");
        return;
      }

      setProgressLabel("Generating thumbnail...");
      let thumbnailUrl = "";
      const thumbBlob = await captureThumbnail(file);
      if (thumbBlob) {
        const videoId = `thumb-${Date.now()}`;
        const thumb = await uploadThumbnail(thumbBlob, userId, videoId);
        if (thumb.url) thumbnailUrl = thumb.url;
      }

      setProgressLabel("Saving...");
      const tags = hashtags
        .split(",")
        .map((t) => t.trim().replace(/^#/, ""))
        .filter(Boolean);

      const result = await createVideo({
        userId,
        title: title || file.name,
        description,
        hashtags: tags,
        streamUrl: uploaded.url,
        storagePath: uploaded.path,
        thumbnailUrl,
      });

      if (result.error) {
        toast(result.error, "error");
        setUploading(false);
        setProgressLabel("");
        return;
      }

      setDone(true);
      toast("Flash posted!", "success");
      setTimeout(() => router.push("/feed"), 1200);
    } catch {
      toast("Something went wrong", "error");
    } finally {
      setUploading(false);
      setProgressLabel("");
    }
  };

  const clear = () => {
    setFile(null);
    if (preview) URL.revokeObjectURL(preview);
    if (thumbPreview) URL.revokeObjectURL(thumbPreview);
    setPreview(null);
    setThumbPreview(null);
    if (fileRef.current) fileRef.current.value = "";
  };

  return (
    <div className="min-h-dvh bg-background pb-24">
      <header className="sticky top-0 z-20 flex items-center justify-between border-b border-border bg-background/80 px-4 py-3 backdrop-blur-md">
        <button
          onClick={() => router.back()}
          className="text-muted hover:text-foreground"
          aria-label="Close"
        >
          <X size={24} />
        </button>
        <h1 className="text-lg font-semibold">Create Flash</h1>
        <div className="w-6" />
      </header>

      <form onSubmit={handleSubmit} className="mx-auto max-w-lg px-4 py-6">
        {!preview ? (
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            className="flex w-full flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-border bg-card py-16 transition hover:border-accent/50 hover:bg-card-hover"
          >
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-accent/10">
              <Upload size={28} className="text-accent" />
            </div>
            <div className="text-center">
              <p className="font-semibold">Upload a video</p>
              <p className="mt-1 text-sm text-muted">
                MP4, MOV · under 100MB · up to 60s recommended
              </p>
            </div>
          </button>
        ) : (
          <div className="relative overflow-hidden rounded-2xl bg-card">
            <video
              src={preview}
              className="aspect-[9/16] max-h-[50vh] w-full object-cover"
              controls
              playsInline
            />
            <button
              type="button"
              onClick={clear}
              className="absolute right-3 top-3 rounded-full bg-background/60 p-2 backdrop-blur-sm"
              aria-label="Remove video"
            >
              <X size={18} />
            </button>
          </div>
        )}

        <input
          ref={fileRef}
          type="file"
          accept="video/*"
          className="hidden"
          onChange={handleFile}
        />

        <div className="mt-6 space-y-4">
          <div>
            <label className="mb-1.5 block text-sm font-medium text-muted">
              Title
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Give your Flash a title"
              maxLength={80}
              className="w-full rounded-xl border border-border bg-card px-4 py-3 text-sm outline-none transition focus:border-accent"
            />
          </div>

          <div>
            <label className="mb-1.5 block text-sm font-medium text-muted">
              Description
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Tell people what this is about..."
              rows={3}
              maxLength={300}
              className="w-full resize-none rounded-xl border border-border bg-card px-4 py-3 text-sm outline-none transition focus:border-accent"
            />
          </div>

          <div>
            <label className="mb-1.5 flex items-center gap-1.5 text-sm font-medium text-muted">
              <Hash size={14} />
              Hashtags
            </label>
            <input
              type="text"
              value={hashtags}
              onChange={(e) => setHashtags(e.target.value)}
              placeholder="funny, dance, tutorial"
              className="w-full rounded-xl border border-border bg-card px-4 py-3 text-sm outline-none transition focus:border-accent"
            />
            <p className="mt-1 text-xs text-muted">Separate with commas</p>
          </div>
        </div>

        <div className="mt-6">
          <label className="mb-1.5 flex items-center gap-1.5 text-sm font-medium text-muted">
            <ImageIcon size={14} />
            Cover image
          </label>
          {thumbPreview ? (
            <div className="overflow-hidden rounded-xl border border-border">
              <img
                src={thumbPreview}
                alt="Cover"
                className="h-28 w-full object-cover"
              />
              <p className="bg-card px-3 py-1.5 text-xs text-muted">
                Auto-captured from video
              </p>
            </div>
          ) : (
            <div className="flex h-20 items-center justify-center rounded-xl border border-dashed border-border bg-card text-sm text-muted">
              Will be generated from first frame
            </div>
          )}
        </div>

        <button
          type="submit"
          disabled={!file || uploading || done}
          className={cn(
            "mt-8 flex w-full items-center justify-center gap-2 rounded-full py-3.5 text-base font-semibold transition",
            done
              ? "bg-success text-foreground"
              : "bg-accent text-foreground hover:bg-accent-hover disabled:opacity-40"
          )}
        >
          {uploading ? (
            <>
              <Loader2 size={20} className="animate-spin" />
              {progressLabel || "Uploading..."}
            </>
          ) : done ? (
            <>
              <Check size={20} />
              Posted!
            </>
          ) : (
            "Post Flash"
          )}
        </button>
      </form>

      <BottomNav />
    </div>
  );
}
