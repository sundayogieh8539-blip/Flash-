import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { AuthProvider } from "@/context/AuthContext";
import { ToastProvider } from "@/context/ToastContext";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: {
    default: "Flash — Share moments that matter",
    template: "%s · Flash",
  },
  description:
    "The fastest way to create, discover, and share short videos. Join creators on Flash.",
  keywords: [
    "video",
    "short video",
    "social media",
    "share videos",
    "flash",
    "reels",
    "tiktok alternative",
  ],
  authors: [{ name: "Flash" }],
  creator: "Flash",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://flash.app",
    siteName: "Flash",
    title: "Flash — Share moments that matter",
    description: "Create and share short videos with the world.",
  },
  twitter: {
    card: "summary_large_image",
    title: "Flash",
    description: "Share moments that matter",
  },
  robots: {
    index: true,
    follow: true,
  },
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "Flash",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: "#e11d48",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full`}
    >
      <body className="min-h-full flex flex-col bg-background text-foreground antialiased">
        <AuthProvider>
          <ToastProvider>{children}</ToastProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
