import { NextResponse } from "next/server";
import { videos } from "@/lib/data";

// GET /api/videos — list videos (mock until server-side Supabase is wired)
export async function GET() {
  const data = videos.map((v) => ({
    ...v,
    createdAt: v.createdAt.toISOString(),
  }));

  return NextResponse.json({
    success: true,
    data,
    count: data.length,
    mode: process.env.NEXT_PUBLIC_SUPABASE_URL ? "supabase-ready" : "demo",
  });
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const newVideo = {
      id: `v-${Date.now()}`,
      userId: body.userId || "u1",
      title: body.title || "Untitled",
      description: body.description || "",
      hashtags: body.hashtags || [],
      thumbnail: body.thumbnail || "",
      videoUrl: body.videoUrl || "",
      likes: 0,
      comments: 0,
      shares: 0,
      views: 0,
      createdAt: new Date().toISOString(),
      duration: body.duration || 0,
      status: "processing",
    };

    return NextResponse.json({ success: true, data: newVideo }, { status: 201 });
  } catch {
    return NextResponse.json(
      { success: false, error: "Invalid request body" },
      { status: 400 }
    );
  }
}
