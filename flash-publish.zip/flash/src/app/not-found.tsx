import Link from "next/link";
import { Zap } from "lucide-react";

export default function NotFound() {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center gap-4 bg-background px-6 text-center">
      <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-accent/20">
        <Zap size={32} className="text-accent" />
      </div>
      <h1 className="text-2xl font-bold">Page not found</h1>
      <p className="max-w-sm text-muted">
        This Flash doesn&apos;t exist or has been removed.
      </p>
      <Link
        href="/feed"
        className="mt-2 rounded-full bg-accent px-6 py-2.5 text-sm font-semibold hover:bg-accent-hover"
      >
        Back to feed
      </Link>
    </div>
  );
}
