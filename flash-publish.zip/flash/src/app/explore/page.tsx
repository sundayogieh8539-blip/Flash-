"use client";

import { useState, useEffect, useMemo } from "react";
import Link from "next/link";
import { Search, TrendingUp, Hash } from "lucide-react";
import BottomNav from "@/components/BottomNav";
import { users } from "@/lib/data";
import { fetchFeedVideos, type Video } from "@/lib/videos";
import { formatCount } from "@/lib/utils";

const trendingTags = [
  { tag: "goldenhour", count: 2.4e6 },
  { tag: "fitness", count: 8.1e6 },
  { tag: "ai", count: 12.3e6 },
  { tag: "streetfood", count: 3.7e6 },
  { tag: "coding", count: 5.2e6 },
  { tag: "dance", count: 15.8e6 },
];

export default function ExplorePage() {
  const [query, setQuery] = useState("");
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchFeedVideos().then((list) => {
      setVideos(list);
      setLoading(false);
    });
  }, []);

  const filtered = useMemo(() => {
    if (!query.trim()) return videos;
    const q = query.toLowerCase();
    return videos.filter(
      (v) =>
        v.title.toLowerCase().includes(q) ||
        v.description.toLowerCase().includes(q) ||
        v.hashtags.some((h) => h.includes(q))
    );
  }, [query, videos]);

  return (
    <div className="min-h-dvh bg-background pb-24">
      <header className="sticky top-0 z-20 border-b border-border bg-background/80 px-4 py-3 backdrop-blur-md">
        <div className="relative">
          <Search
            size={18}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-muted"
          />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search videos, creators, hashtags..."
            className="w-full rounded-full border border-border bg-card py-2.5 pl-10 pr-4 text-sm outline-none transition focus:border-accent"
          />
        </div>
      </header>

      <div className="px-4 py-5">
        {!query && (
          <>
            <div className="mb-4 flex items-center gap-2">
              <TrendingUp size={18} className="text-accent" />
              <h2 className="font-semibold">Trending hashtags</h2>
            </div>
            <div className="mb-8 flex flex-wrap gap-2">
              {trendingTags.map(({ tag, count }) => (
                <Link
                  key={tag}
                  href={`/tag/${tag}`}
                  className="flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 text-sm transition hover:border-accent/50"
                >
                  <Hash size={14} className="text-accent" />
                  {tag}
                  <span className="text-xs text-muted">
                    {formatCount(count)}
                  </span>
                </Link>
              ))}
            </div>

            <h2 className="mb-3 font-semibold">Suggested creators</h2>
            <div className="mb-8 flex gap-4 overflow-x-auto no-scrollbar pb-2">
              {users.map((u) => (
                <Link
                  key={u.id}
                  href="/profile"
                  className="flex w-20 shrink-0 flex-col items-center gap-1.5"
                >
                  <img
                    src={u.avatar}
                    alt={u.displayName}
                    className="h-16 w-16 rounded-full border-2 border-border object-cover"
                  />
                  <span className="w-full truncate text-center text-xs font-medium">
                    {u.displayName.split(" ")[0]}
                  </span>
                </Link>
              ))}
            </div>
          </>
        )}

        <h2 className="mb-3 font-semibold">
          {query ? `Results for "${query}"` : "Popular right now"}
        </h2>

        {loading ? (
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <div
                key={i}
                className="aspect-[9/14] animate-pulse rounded-xl bg-white/10"
              />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            {filtered.map((v) => {
              const user = users.find((u) => u.id === v.userId);
              return (
                <Link
                  key={v.id}
                  href="/feed"
                  className="group relative aspect-[9/14] overflow-hidden rounded-xl bg-card"
                >
                  <img
                    src={v.thumbnail || v.videoUrl}
                    alt={v.title}
                    className="h-full w-full object-cover transition group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-2.5">
                    <p className="line-clamp-2 text-xs font-medium leading-snug">
                      {v.title}
                    </p>
                    <p className="mt-0.5 text-[10px] text-muted">
                      @{user?.username || "creator"} · {formatCount(v.views)}{" "}
                      views
                    </p>
                  </div>
                </Link>
              );
            })}
          </div>
        )}

        {!loading && filtered.length === 0 && (
          <div className="py-16 text-center">
            <p className="text-sm text-muted">
              No results for &quot;{query}&quot;
            </p>
            <button
              onClick={() => setQuery("")}
              className="mt-3 text-sm font-medium text-accent"
            >
              Clear search
            </button>
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}
