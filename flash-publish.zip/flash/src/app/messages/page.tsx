"use client";

import { useState } from "react";
import { Heart, UserPlus, MessageCircle, AtSign } from "lucide-react";
import BottomNav from "@/components/BottomNav";
import { users } from "@/lib/data";
import { cn } from "@/lib/utils";

type Tab = "all" | "likes" | "follows" | "comments";

const activities = [
  {
    id: "1",
    type: "like" as const,
    userId: "u2",
    text: "liked your video",
    time: "2h",
    unread: true,
  },
  {
    id: "2",
    type: "follow" as const,
    userId: "u3",
    text: "started following you",
    time: "5h",
    unread: true,
  },
  {
    id: "3",
    type: "comment" as const,
    userId: "u4",
    text: 'commented: "This is amazing 🔥"',
    time: "1d",
    unread: false,
  },
  {
    id: "4",
    type: "like" as const,
    userId: "u5",
    text: "liked your video",
    time: "1d",
    unread: false,
  },
  {
    id: "5",
    type: "mention" as const,
    userId: "u2",
    text: "mentioned you in a comment",
    time: "2d",
    unread: false,
  },
  {
    id: "6",
    type: "follow" as const,
    userId: "u4",
    text: "started following you",
    time: "3d",
    unread: false,
  },
];

const iconMap = {
  like: Heart,
  follow: UserPlus,
  comment: MessageCircle,
  mention: AtSign,
};

export default function MessagesPage() {
  const [tab, setTab] = useState<Tab>("all");

  const filtered =
    tab === "all"
      ? activities
      : activities.filter((a) => {
          if (tab === "likes") return a.type === "like";
          if (tab === "follows") return a.type === "follow";
          if (tab === "comments")
            return a.type === "comment" || a.type === "mention";
          return true;
        });

  const unreadCount = activities.filter((a) => a.unread).length;

  return (
    <div className="min-h-dvh bg-background pb-24">
      <header className="sticky top-0 z-20 border-b border-border bg-background/80 px-4 py-3 backdrop-blur-md">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold">Inbox</h1>
          {unreadCount > 0 && (
            <span className="rounded-full bg-accent px-2 py-0.5 text-xs font-bold">
              {unreadCount} new
            </span>
          )}
        </div>

        <div className="mt-3 flex gap-2 overflow-x-auto no-scrollbar">
          {(
            [
              ["all", "All"],
              ["likes", "Likes"],
              ["follows", "Follows"],
              ["comments", "Comments"],
            ] as const
          ).map(([key, label]) => (
            <button
              key={key}
              onClick={() => setTab(key)}
              className={cn(
                "shrink-0 rounded-full px-3.5 py-1.5 text-sm font-medium transition",
                tab === key
                  ? "bg-white text-black"
                  : "bg-card text-muted hover:text-foreground"
              )}
            >
              {label}
            </button>
          ))}
        </div>
      </header>

      <div className="px-2 py-2">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-20 text-muted">
            <MessageCircle size={40} strokeWidth={1.5} />
            <p className="text-sm">No activity yet</p>
          </div>
        ) : (
          filtered.map((a) => {
            const user = users.find((u) => u.id === a.userId);
            if (!user) return null;
            const Icon = iconMap[a.type];
            return (
              <div
                key={a.id}
                className={cn(
                  "flex items-center gap-3 rounded-xl px-3 py-3 transition hover:bg-card",
                  a.unread && "bg-card/50"
                )}
              >
                <div className="relative">
                  <img
                    src={user.avatar}
                    alt={user.displayName}
                    className="h-12 w-12 rounded-full object-cover"
                  />
                  <div className="absolute -bottom-0.5 -right-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-card">
                    <Icon
                      size={12}
                      className={cn(
                        a.type === "like" && "fill-accent text-accent",
                        a.type === "follow" && "text-blue-400",
                        a.type === "comment" && "text-green-400",
                        a.type === "mention" && "text-purple-400"
                      )}
                    />
                  </div>
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm leading-snug">
                    <span className="font-semibold">{user.displayName}</span>{" "}
                    <span className="text-muted">{a.text}</span>
                  </p>
                  <p className="mt-0.5 text-xs text-muted">{a.time}</p>
                </div>
                {a.unread && (
                  <div className="h-2 w-2 shrink-0 rounded-full bg-accent" />
                )}
              </div>
            );
          })
        )}
      </div>

      <BottomNav />
    </div>
  );
}
