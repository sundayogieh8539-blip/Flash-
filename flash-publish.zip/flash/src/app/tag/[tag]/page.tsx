"use client";

import { use } from "react";
import Link from "next/link";
import { ArrowLeft, Hash } from "lucide-react";
import BottomNav from "@/components/BottomNav";
import { videos, users } from "@/lib/data";
import { formatCount } from "@/lib/utils";

export default function TagPage({
  params,
}: {
  params: Promise<{ tag: string }>;
}) {
  const { tag } = use(params);
  const decoded = decodeURIComponent(tag).toLowerCase();
  const matched = videos.filter((v) =>
    v.hashtags.some((h) => h.toLowerCase() === decoded)
  );
  const totalViews = matched.reduce((s, v) => s + v.views, 0);

  return (
    <div className="min-h-dvh bg-background pb-24">
      <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-border bg-background/80 px-4 py-3 backdrop-blur-md">
        <Link href="/explore" className="text-muted hover:text-foreground">
          <ArrowLeft size={22} />
        </Link>
        <div className="flex items-center gap-2">
          <Hash size={18} className="text-accent" />
          <h1 className="text-lg font-semibold">{decoded}</h1>
        </div>
      </header>

      <div className="px-4 py-4">
        <p className="text-sm text-muted">
          {matched.length} videos · {formatCount(totalViews)} views
        </p>
      </div>

      <div className="grid grid-cols-2 gap-0.5 sm:grid-cols-3">
        {matched.map((v) => {
          const user = users.find((u) => u.id === v.userId);
          return (
            <Link
              key={v.id}
              href="/feed"
              className="relative aspect-[9/14] overflow-hidden bg-card"
            >
              <img
                src={v.thumbnail}
                alt={v.title}
                className="h-full w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
              <div className="absolute bottom-2 left-2 right-2">
                <p className="line-clamp-1 text-xs font-medium">{v.title}</p>
                <p className="text-[10px] text-muted">
                  @{user?.username} · {formatCount(v.views)}
                </p>
              </div>
            </Link>
          );
        })}
      </div>

      {matched.length === 0 && (
        <p className="py-16 text-center text-sm text-muted">
          No videos with #{decoded} yet
        </p>
      )}

      <BottomNav />
    </div>
  );
}
