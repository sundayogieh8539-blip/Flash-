"use client";

import { useRouter } from "next/navigation";
import {
  ArrowLeft,
  Bell,
  Moon,
  Shield,
  HelpCircle,
  LogOut,
  ChevronRight,
  User,
} from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import BottomNav from "@/components/BottomNav";

const sections = [
  {
    title: "Account",
    items: [
      { icon: User, label: "Edit profile", href: "/profile" },
      { icon: Bell, label: "Notifications", href: "#" },
      { icon: Shield, label: "Privacy & safety", href: "#" },
    ],
  },
  {
    title: "Preferences",
    items: [
      { icon: Moon, label: "Dark mode", href: "#", value: "On" },
      { icon: HelpCircle, label: "Help & support", href: "#" },
    ],
  },
];

export default function SettingsPage() {
  const router = useRouter();
  const { user, isLoggedIn, logout } = useAuth();

  return (
    <div className="min-h-dvh bg-background pb-24">
      <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-border bg-background/80 px-4 py-3 backdrop-blur-md">
        <button
          onClick={() => router.back()}
          className="text-muted hover:text-foreground"
          aria-label="Back"
        >
          <ArrowLeft size={22} />
        </button>
        <h1 className="text-lg font-semibold">Settings</h1>
      </header>

      {isLoggedIn && user && (
        <div className="flex items-center gap-3 border-b border-border px-4 py-4">
          <img
            src={user.avatar}
            alt={user.displayName}
            className="h-14 w-14 rounded-full object-cover"
          />
          <div>
            <p className="font-semibold">{user.displayName}</p>
            <p className="text-sm text-muted">@{user.username}</p>
          </div>
        </div>
      )}

      <div className="px-4 py-4">
        {sections.map((section) => (
          <div key={section.title} className="mb-6">
            <h2 className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted">
              {section.title}
            </h2>
            <div className="overflow-hidden rounded-xl border border-border bg-card">
              {section.items.map((item, i) => (
                <button
                  key={item.label}
                  onClick={() => item.href !== "#" && router.push(item.href)}
                  className={`flex w-full items-center gap-3 px-4 py-3.5 text-left transition hover:bg-card-hover ${
                    i < section.items.length - 1 ? "border-b border-border" : ""
                  }`}
                >
                  <item.icon size={18} className="text-muted" />
                  <span className="flex-1 text-sm font-medium">{item.label}</span>
                  {"value" in item && item.value && (
                    <span className="text-sm text-muted">{item.value}</span>
                  )}
                  <ChevronRight size={16} className="text-muted" />
                </button>
              ))}
            </div>
          </div>
        ))}

        {isLoggedIn && (
          <button
            onClick={() => {
              logout();
              router.push("/");
            }}
            className="flex w-full items-center justify-center gap-2 rounded-xl border border-border bg-card py-3.5 text-sm font-semibold text-accent transition hover:bg-card-hover"
          >
            <LogOut size={18} />
            Log out
          </button>
        )}
      </div>

      <p className="px-4 pb-4 text-center text-xs text-muted">
        Flash v0.1.0 · Demo build
      </p>

      <BottomNav />
    </div>
  );
}
