"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Settings,
  Grid3X3,
  Heart,
  Bookmark,
  Share2,
  LogOut,
} from "lucide-react";
import BottomNav from "@/components/BottomNav";
import { useAuth } from "@/context/AuthContext";
import { users, getVideosByUser } from "@/lib/data";
import { formatCount, cn } from "@/lib/utils";
import { isFollowing, toggleFollow } from "@/lib/store";
import { useToast } from "@/context/ToastContext";

export default function ProfilePage() {
  const { user, isLoggedIn, login, logout } = useAuth();
  const router = useRouter();
  const { toast } = useToast();
  const [tab, setTab] = useState<"videos" | "liked" | "saved">("videos");
  const [following, setFollowing] = useState(false);

  const currentUser = user || users[0];
  const userVideos = getVideosByUser(currentUser.id);

  useEffect(() => {
    setFollowing(isFollowing(currentUser.id));
  }, [currentUser.id]);

  if (!isLoggedIn) {
    return (
      <div className="flex min-h-dvh flex-col items-center justify-center gap-4 bg-background px-6 pb-24">
        <h1 className="text-2xl font-bold">Your profile</h1>
        <p className="text-center text-muted">
          Log in to see your videos, likes, and followers.
        </p>
        <button
          onClick={() => login()}
          className="rounded-full bg-accent px-8 py-3 font-semibold hover:bg-accent-hover"
        >
          Log in
        </button>
        <BottomNav />
      </div>
    );
  }

  const handleFollow = () => {
    const nowFollowing = toggleFollow(currentUser.id, user?.id);
    setFollowing(nowFollowing);
    toast(nowFollowing ? `Following @${currentUser.username}` : "Unfollowed", "success");
  };

  return (
    <div className="min-h-dvh bg-background pb-24">
      <header className="sticky top-0 z-20 flex items-center justify-between border-b border-border bg-background/80 px-4 py-3 backdrop-blur-md">
        <h1 className="text-lg font-semibold">@{currentUser.username}</h1>
        <div className="flex items-center gap-3">
          <button className="text-muted hover:text-foreground" aria-label="Share">
            <Share2 size={20} />
          </button>
          <button
            onClick={() => {
              logout();
              router.push("/");
            }}
            className="text-muted hover:text-foreground"
            aria-label="Log out"
          >
            <LogOut size={20} />
          </button>
          <Link
            href="/settings"
            className="text-muted hover:text-foreground"
            aria-label="Settings"
          >
            <Settings size={20} />
          </Link>
        </div>
      </header>

      <div className="px-4 pt-6">
        <div className="flex items-start gap-4">
          <img
            src={currentUser.avatar}
            alt={currentUser.displayName}
            className="h-20 w-20 rounded-full border-2 border-border object-cover"
          />
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold">{currentUser.displayName}</h2>
              {currentUser.verified && (
                <span className="rounded bg-accent px-1.5 text-xs font-bold">
                  ✓
                </span>
              )}
            </div>
            <p className="text-sm text-muted">@{currentUser.username}</p>
            <div className="mt-3 flex gap-5 text-sm">
              <div>
                <span className="font-bold">
                  {formatCount(userVideos.length)}
                </span>{" "}
                <span className="text-muted">Videos</span>
              </div>
              <div>
                <span className="font-bold">
                  {formatCount(currentUser.followers)}
                </span>{" "}
                <span className="text-muted">Followers</span>
              </div>
              <div>
                <span className="font-bold">
                  {formatCount(currentUser.following)}
                </span>{" "}
                <span className="text-muted">Following</span>
              </div>
            </div>
          </div>
        </div>

        <p className="mt-4 text-sm leading-relaxed">{currentUser.bio}</p>
        <p className="mt-1 text-sm text-muted">
          {formatCount(currentUser.likes)} total likes
        </p>

        <div className="mt-4 flex gap-2">
          <button
            onClick={handleFollow}
            className={cn(
              "flex-1 rounded-full py-2.5 text-sm font-semibold transition",
              following
                ? "border border-border bg-card text-foreground"
                : "bg-accent text-foreground hover:bg-accent-hover"
            )}
          >
            {following ? "Following" : "Follow"}
          </button>
          <button className="flex-1 rounded-full border border-border bg-card py-2.5 text-sm font-semibold transition hover:bg-card-hover">
            Message
          </button>
        </div>
      </div>

      <div className="mt-6 flex border-b border-border">
        {[
          { key: "videos" as const, icon: Grid3X3, label: "Videos" },
          { key: "liked" as const, icon: Heart, label: "Liked" },
          { key: "saved" as const, icon: Bookmark, label: "Saved" },
        ].map(({ key, icon: Icon, label }) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={cn(
              "flex flex-1 items-center justify-center gap-1.5 py-3 text-sm font-medium transition",
              tab === key
                ? "border-b-2 border-white text-foreground"
                : "text-muted hover:text-foreground"
            )}
          >
            <Icon size={16} />
            {label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-0.5">
        {tab === "videos" &&
          userVideos.map((v) => (
            <Link
              key={v.id}
              href="/feed"
              className="relative aspect-[9/16] overflow-hidden bg-card"
            >
              <img
                src={v.thumbnail}
                alt={v.title}
                className="h-full w-full object-cover transition hover:scale-105"
              />
              <div className="absolute bottom-1 left-1 flex items-center gap-1 text-xs font-semibold drop-shadow">
                <Heart size={12} className="fill-white" />
                {formatCount(v.likes)}
              </div>
            </Link>
          ))}
        {tab !== "videos" && (
          <div className="col-span-3 py-16 text-center text-muted">
            <p className="text-sm">No {tab} videos yet</p>
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}
