"use client";

import { useState, useEffect } from "react";
import VideoCard from "@/components/VideoCard";
import BottomNav from "@/components/BottomNav";
import Onboarding from "@/components/Onboarding";
import { cn } from "@/lib/utils";
import { fetchFeedVideos, fetchFollowingIds, type Video } from "@/lib/videos";
import { useAuth } from "@/context/AuthContext";

type Tab = "foryou" | "following";

export default function FeedPage() {
  const { user, isLoggedIn } = useAuth();
  const [tab, setTab] = useState<Tab>("foryou");
  const [feedVideos, setFeedVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setLoading(true);
      let followingIds: string[] | undefined;

      if (tab === "following" && isLoggedIn && user) {
        followingIds = await fetchFollowingIds(user.id);
      }

      const list = await fetchFeedVideos(
        tab === "following" ? { followingIds: followingIds || [] } : undefined
      );

      if (!cancelled) {
        setFeedVideos(list);
        setLoading(false);
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [tab, isLoggedIn, user]);

  return (
    <div className="relative h-dvh w-full overflow-hidden bg-black text-white">
      <Onboarding />

      <div className="pointer-events-none absolute left-0 right-0 top-0 z-20 flex items-center justify-center pt-3">
        <div className="pointer-events-auto flex items-center gap-6 rounded-full bg-black/40 px-2 py-1 backdrop-blur-md">
          <button
            onClick={() => setTab("following")}
            className={cn(
              "px-3 py-1 text-sm font-semibold transition",
              tab === "following"
                ? "text-white"
                : "text-white/50 hover:text-white/80"
            )}
          >
            Following
          </button>
          <button
            onClick={() => setTab("foryou")}
            className={cn(
              "px-3 py-1 text-sm font-semibold transition",
              tab === "foryou" ? "text-white" : "text-white/50 hover:text-white/80"
            )}
          >
            For You
          </button>
        </div>
      </div>

      <div className="h-full w-full snap-y snap-mandatory overflow-y-scroll no-scrollbar">
        {loading ? (
          <div className="flex h-full flex-col items-center justify-center gap-3">
            <div className="h-10 w-10 animate-spin rounded-full border-2 border-accent border-t-transparent" />
            <p className="text-sm text-white/60">Loading Flashes...</p>
          </div>
        ) : feedVideos.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center gap-3 px-6 text-center">
            <p className="text-lg font-semibold text-white">No videos yet</p>
            <p className="text-sm text-white/60">
              {tab === "following"
                ? "Follow creators to see their Flashes here."
                : "Be the first to post a Flash."}
            </p>
            {tab === "following" && (
              <button
                onClick={() => setTab("foryou")}
                className="mt-2 rounded-full bg-accent px-5 py-2 text-sm font-semibold text-white"
              >
                Explore For You
              </button>
            )}
          </div>
        ) : (
          feedVideos.map((video) => (
            <VideoCard key={`${tab}-${video.id}`} video={video} />
          ))
        )}
      </div>

      <BottomNav />
    </div>
  );
}
