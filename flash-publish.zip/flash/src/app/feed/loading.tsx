export default function FeedLoading() {
  return (
    <div className="flex h-dvh w-full items-center justify-center bg-black">
      <div className="flex flex-col items-center gap-3">
        <div className="h-10 w-10 animate-spin rounded-full border-2 border-accent border-t-transparent" />
        <p className="text-sm text-muted">Loading Flashes...</p>
      </div>
    </div>
  );
}
