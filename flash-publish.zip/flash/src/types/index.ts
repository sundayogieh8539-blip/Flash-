export interface User {
  id: string;
  username: string;
  displayName: string;
  avatar: string;
  bio: string;
  followers: number;
  following: number;
  likes: number;
  verified?: boolean;
}

export interface Video {
  id: string;
  userId: string;
  title: string;
  description: string;
  hashtags: string[];
  thumbnail: string;
  videoUrl: string;
  likes: number;
  comments: number;
  shares: number;
  views: number;
  createdAt: Date;
  duration: number;
}

export interface Comment {
  id: string;
  videoId: string;
  userId: string;
  text: string;
  likes: number;
  createdAt: Date;
}
