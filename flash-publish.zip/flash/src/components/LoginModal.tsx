"use client";

import { useState } from "react";
import { X, Zap, Mail, Loader2 } from "lucide-react";
import { users } from "@/lib/data";
import { useAuth } from "@/context/AuthContext";
import { cn } from "@/lib/utils";

interface LoginModalProps {
  open: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export default function LoginModal({ open, onClose, onSuccess }: LoginModalProps) {
  const { login, loginWithEmail, signUp, isDemo } = useAuth();
  const [mode, setMode] = useState<"demo" | "email">("demo");
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  if (!open) return null;

  const handleEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    const result = isSignUp
      ? await signUp(email, password, username || email.split("@")[0])
      : await loginWithEmail(email, password);
    setLoading(false);
    if (result.error) {
      setError(result.error);
      return;
    }
    onClose();
    onSuccess?.();
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-end justify-center sm:items-center">
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
      />
      <div className="relative z-10 w-full max-w-md rounded-t-3xl border border-border bg-white p-6 shadow-xl sm:rounded-3xl animate-fade-up">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-full p-1 text-muted hover:text-white"
          aria-label="Close"
        >
          <X size={20} />
        </button>

        <div className="mb-5 flex flex-col items-center text-center">
          <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-accent">
            <Zap size={28} className="fill-white text-white" />
          </div>
          <h2 className="text-xl font-bold">
            {isSignUp ? "Join Flash" : "Log in to Flash"}
          </h2>
          <p className="mt-1 text-sm text-muted">
            {isDemo
              ? "Demo mode — pick an account"
              : "Use email or a demo account"}
          </p>
        </div>

        {/* Mode toggle when Supabase is live */}
        {!isDemo && (
          <div className="mb-4 flex rounded-full bg-background p-1">
            <button
              onClick={() => setMode("demo")}
              className={cn(
                "flex-1 rounded-full py-2 text-sm font-medium transition",
                mode === "demo" ? "bg-card text-white" : "text-muted"
              )}
            >
              Demo
            </button>
            <button
              onClick={() => setMode("email")}
              className={cn(
                "flex-1 rounded-full py-2 text-sm font-medium transition",
                mode === "email" ? "bg-card text-white" : "text-muted"
              )}
            >
              Email
            </button>
          </div>
        )}

        {(isDemo || mode === "demo") && (
          <div className="space-y-2">
            {users.map((u) => (
              <button
                key={u.id}
                onClick={() => {
                  login(u.username);
                  onClose();
                  onSuccess?.();
                }}
                className="flex w-full items-center gap-3 rounded-xl border border-border bg-card px-4 py-3 text-left transition hover:border-accent hover:bg-card-hover"
              >
                <img
                  src={u.avatar}
                  alt={u.displayName}
                  className="h-10 w-10 rounded-full object-cover"
                />
                <div className="min-w-0 flex-1">
                  <p className="font-semibold truncate">{u.displayName}</p>
                  <p className="text-xs text-muted truncate">@{u.username}</p>
                </div>
                {u.verified && (
                  <span className="rounded bg-accent px-1.5 text-[10px] font-bold">
                    ✓
                  </span>
                )}
              </button>
            ))}
          </div>
        )}

        {!isDemo && mode === "email" && (
          <form onSubmit={handleEmail} className="space-y-3">
            {isSignUp && (
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Username"
                className="w-full rounded-xl border border-border bg-background px-4 py-3 text-sm outline-none focus:border-accent"
              />
            )}
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email"
              required
              className="w-full rounded-xl border border-border bg-background px-4 py-3 text-sm outline-none focus:border-accent"
            />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              required
              minLength={6}
              className="w-full rounded-xl border border-border bg-background px-4 py-3 text-sm outline-none focus:border-accent"
            />
            {error && (
              <p className="text-sm text-accent">{error}</p>
            )}
            <button
              type="submit"
              disabled={loading}
              className="flex w-full items-center justify-center gap-2 rounded-full bg-accent py-3 font-semibold hover:bg-accent-hover disabled:opacity-50"
            >
              {loading ? (
                <Loader2 size={18} className="animate-spin" />
              ) : (
                <Mail size={18} />
              )}
              {isSignUp ? "Create account" : "Log in"}
            </button>
            <button
              type="button"
              onClick={() => {
                setIsSignUp(!isSignUp);
                setError("");
              }}
              className="w-full text-center text-sm text-muted hover:text-white"
            >
              {isSignUp
                ? "Already have an account? Log in"
                : "Need an account? Sign up"}
            </button>
          </form>
        )}

        {isDemo && (
          <p className="mt-5 text-center text-xs text-muted">
            Demo mode — data stays in your browser. Add Supabase keys to enable real accounts.
          </p>
        )}
      </div>
    </div>
  );
}
