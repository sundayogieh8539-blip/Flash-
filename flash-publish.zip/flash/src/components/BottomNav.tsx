"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Home, Compass, PlusSquare, MessageCircle, User } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import LoginModal from "./LoginModal";

const navItems = [
  { href: "/feed", icon: Home, label: "Home" },
  { href: "/explore", icon: Compass, label: "Explore" },
  { href: "/upload", icon: PlusSquare, label: "Create", accent: true, auth: true },
  { href: "/messages", icon: MessageCircle, label: "Inbox", auth: true, badge: 2 },
  { href: "/profile", icon: User, label: "Profile" },
];

export default function BottomNav() {
  const pathname = usePathname();
  const router = useRouter();
  const { isLoggedIn } = useAuth();
  const [loginOpen, setLoginOpen] = useState(false);
  const [pendingHref, setPendingHref] = useState<string | null>(null);

  const handleClick = (
    e: React.MouseEvent,
    href: string,
    needsAuth?: boolean
  ) => {
    if (needsAuth && !isLoggedIn) {
      e.preventDefault();
      setPendingHref(href);
      setLoginOpen(true);
    }
  };

  return (
    <>
      <nav className="fixed bottom-0 left-0 right-0 z-50 border-t border-border bg-white/95 backdrop-blur-md safe-bottom">
        <div className="mx-auto flex max-w-lg items-center justify-around px-2 py-2">
          {navItems.map(({ href, icon: Icon, label, accent, auth, badge }) => {
            const isActive =
              pathname === href || (href === "/feed" && pathname === "/");
            return (
              <Link
                key={href}
                href={href}
                onClick={(e) => handleClick(e, href, auth)}
                className={cn(
                  "relative flex flex-col items-center gap-0.5 px-3 py-1.5 transition-colors",
                  accent
                    ? "text-accent"
                    : isActive
                      ? "text-accent"
                      : "text-muted hover:text-accent"
                )}
              >
                <div className="relative">
                  <Icon
                    size={accent ? 28 : 24}
                    strokeWidth={isActive || accent ? 2.5 : 2}
                    className={cn(
                      accent && "drop-shadow-[0_0_8px_rgba(225,29,72,0.35)]"
                    )}
                  />
                  {badge && badge > 0 && (
                    <span className="absolute -right-2 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-accent px-1 text-[10px] font-bold text-white">
                      {badge}
                    </span>
                  )}
                </div>
                <span className="text-[10px] font-medium">{label}</span>
              </Link>
            );
          })}
        </div>
      </nav>

      <LoginModal
        open={loginOpen}
        onClose={() => {
          setLoginOpen(false);
          setPendingHref(null);
        }}
        onSuccess={() => {
          if (pendingHref) {
            router.push(pendingHref);
            setPendingHref(null);
          }
        }}
      />
    </>
  );
}
