"use client";

import { useState } from "react";
import { X, Heart, Send } from "lucide-react";
import { getCommentsForVideo, getUser, Comment } from "@/lib/data";
import { formatCount, timeAgo, cn } from "@/lib/utils";

interface CommentsSheetProps {
  videoId: string;
  open: boolean;
  onClose: () => void;
}

export default function CommentsSheet({ videoId, open, onClose }: CommentsSheetProps) {
  const existing = getCommentsForVideo(videoId);
  const [comments, setComments] = useState<Comment[]>(existing);
  const [text, setText] = useState("");

  if (!open) return null;

  const handleSend = () => {
    if (!text.trim()) return;
    const newComment: Comment = {
      id: `c-${Date.now()}`,
      videoId,
      userId: "u1", // current user mock
      text: text.trim(),
      likes: 0,
      createdAt: new Date(),
    };
    setComments((prev) => [newComment, ...prev]);
    setText("");
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-end justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Sheet */}
      <div className="relative z-10 flex max-h-[70dvh] w-full max-w-lg flex-col rounded-t-3xl bg-card animate-fade-up">
        {/* Handle + header */}
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <div className="w-8" />
          <div className="flex flex-col items-center">
            <div className="mb-2 h-1 w-10 rounded-full bg-muted/50" />
            <span className="text-sm font-semibold">
              {formatCount(comments.length)} comments
            </span>
          </div>
          <button onClick={onClose} className="rounded-full p-1 hover:bg-white/10">
            <X size={20} />
          </button>
        </div>

        {/* Comments list */}
        <div className="flex-1 overflow-y-auto px-4 py-3">
          {comments.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted">
              Be the first to comment
            </p>
          ) : (
            <div className="space-y-4">
              {comments.map((c) => {
                const user = getUser(c.userId);
                if (!user) return null;
                return (
                  <div key={c.id} className="flex gap-3">
                    <img
                      src={user.avatar}
                      alt={user.displayName}
                      className="h-9 w-9 shrink-0 rounded-full object-cover"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-baseline gap-2">
                        <span className="text-sm font-semibold">
                          {user.username}
                        </span>
                        <span className="text-xs text-muted">
                          {timeAgo(c.createdAt)}
                        </span>
                      </div>
                      <p className="mt-0.5 text-sm leading-snug">{c.text}</p>
                      <button className="mt-1 flex items-center gap-1 text-xs text-muted hover:text-white">
                        <Heart size={12} />
                        {c.likes > 0 && formatCount(c.likes)}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Input */}
        <div className="border-t border-border p-3 safe-bottom">
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
              placeholder="Add a comment..."
              className="flex-1 rounded-full border border-border bg-background px-4 py-2.5 text-sm outline-none focus:border-accent"
            />
            <button
              onClick={handleSend}
              disabled={!text.trim()}
              className={cn(
                "rounded-full p-2.5 transition",
                text.trim()
                  ? "bg-accent text-white"
                  : "bg-border text-muted"
              )}
            >
              <Send size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
