"use client";

import { useState, useRef, useEffect } from "react";
import Link from "next/link";
import {
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  Volume2,
  VolumeX,
  Play,
  MoreHorizontal,
} from "lucide-react";
import { Video, getUser } from "@/lib/data";
import { formatCount, timeAgo, cn } from "@/lib/utils";
import CommentsSheet from "./CommentsSheet";
import { useToast } from "@/context/ToastContext";
import { useAuth } from "@/context/AuthContext";
import { toggleLikeDb } from "@/lib/videos";

interface VideoCardProps {
  video: Video;
}

export default function VideoCard({ video }: VideoCardProps) {
  const user = getUser(video.userId);
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const { user } = useAuth();
  const [liked, setLiked] = useState(false);
  const [saved, setSaved] = useState(false);
  const [muted, setMuted] = useState(true);
  const [playing, setPlaying] = useState(false);
  const [likeCount, setLikeCount] = useState(video.likes);
  const [showHeart, setShowHeart] = useState(false);
  const [commentsOpen, setCommentsOpen] = useState(false);
  const [progress, setProgress] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        const vid = videoRef.current;
        if (!vid) return;
        if (entry.isIntersecting && entry.intersectionRatio > 0.6) {
          vid.play().catch(() => {});
          setPlaying(true);
        } else {
          vid.pause();
          setPlaying(false);
        }
      },
      { threshold: [0.6] }
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    try {
      const likes = JSON.parse(localStorage.getItem("flash_likes") || "{}");
      if (likes[video.id]) {
        setLiked(true);
        setLikeCount(video.likes + 1);
      }
    } catch {
      // ignore
    }
  }, [video.id, video.likes]);

  // Progress bar
  useEffect(() => {
    const vid = videoRef.current;
    if (!vid) return;

    const onTimeUpdate = () => {
      if (vid.duration) {
        setProgress((vid.currentTime / vid.duration) * 100);
      }
    };
    vid.addEventListener("timeupdate", onTimeUpdate);
    return () => vid.removeEventListener("timeupdate", onTimeUpdate);
  }, []);

  if (!user) return null;

  const togglePlay = () => {
    const vid = videoRef.current;
    if (!vid) return;
    if (vid.paused) {
      vid.play().catch(() => {});
      setPlaying(true);
    } else {
      vid.pause();
      setPlaying(false);
    }
  };

  const handleDoubleTap = () => {
    if (!liked) {
      setLiked(true);
      setLikeCount((c) => c + 1);
      try {
        const likes = JSON.parse(localStorage.getItem("flash_likes") || "{}");
        likes[video.id] = true;
        localStorage.setItem("flash_likes", JSON.stringify(likes));
      } catch {
        // ignore
      }
    }
    setShowHeart(true);
    setTimeout(() => setShowHeart(false), 600);
  };

  const toggleLike = () => {
    setLiked((prev) => {
      const next = !prev;
      setLikeCount((c) => (prev ? c - 1 : c + 1));
      try {
        const likes = JSON.parse(localStorage.getItem("flash_likes") || "{}");
        if (next) likes[video.id] = true;
        else delete likes[video.id];
        localStorage.setItem("flash_likes", JSON.stringify(likes));
      } catch {
        // ignore
      }
      if (user) {
        toggleLikeDb(video.id, user.id, prev);
      }
      if (next) toast("Liked!", "success");
      return next;
    });
  };

  const handleShare = async () => {
    const url = `${typeof window !== "undefined" ? window.location.origin : ""}/feed?v=${video.id}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: video.title,
          text: video.description,
          url,
        });
      } catch {
        // cancelled
      }
    } else {
      try {
        await navigator.clipboard.writeText(url);
        toast("Link copied!", "success");
      } catch {
        toast("Could not copy link", "error");
      }
    }
  };

  const toggleSave = () => {
    setSaved((s) => {
      const next = !s;
      toast(next ? "Saved" : "Removed from saved", "info");
      return next;
    });
  };

  return (
    <div
      ref={containerRef}
      className="relative h-[calc(100dvh-4rem)] w-full snap-start snap-always overflow-hidden bg-black"
    >
      <div
        className="absolute inset-0 cursor-pointer"
        onClick={togglePlay}
        onDoubleClick={handleDoubleTap}
      >
        <video
          ref={videoRef}
          src={video.videoUrl}
          poster={video.thumbnail}
          className="h-full w-full object-cover"
          loop
          playsInline
          muted={muted}
          preload="metadata"
          onPlay={() => setPlaying(true)}
          onPause={() => setPlaying(false)}
        />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/70" />
      </div>

      {/* Progress bar */}
      <div className="absolute bottom-0 left-0 right-0 z-20 h-0.5 bg-white/20">
        <div
          className="h-full bg-accent transition-[width] duration-100"
          style={{ width: `${progress}%` }}
        />
      </div>

      {showHeart && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <Heart
            size={100}
            className="animate-heart fill-accent text-accent drop-shadow-lg"
          />
        </div>
      )}

      {!playing && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div className="rounded-full bg-black/40 p-4 backdrop-blur-sm">
            <Play size={40} className="fill-white text-white" />
          </div>
        </div>
      )}

      <div className="absolute left-0 right-0 top-0 z-10 flex items-center justify-between px-4 pt-12">
        <span className="text-sm font-semibold tracking-wide opacity-0">
          Flash
        </span>
        <button
          onClick={(e) => {
            e.stopPropagation();
            setMuted((m) => !m);
          }}
          className="rounded-full bg-black/40 p-2 backdrop-blur-sm"
          aria-label={muted ? "Unmute" : "Mute"}
        >
          {muted ? <VolumeX size={18} /> : <Volume2 size={18} />}
        </button>
      </div>

      <div className="absolute bottom-24 right-3 z-10 flex flex-col items-center gap-5">
        <Link
          href="/profile"
          onClick={(e) => e.stopPropagation()}
          className="relative"
        >
          <img
            src={user.avatar}
            alt={user.displayName}
            className="h-12 w-12 rounded-full border-2 border-white object-cover"
          />
          <div className="absolute -bottom-1 left-1/2 flex h-5 w-5 -translate-x-1/2 items-center justify-center rounded-full bg-accent text-[10px] font-bold">
            +
          </div>
        </Link>

        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleLike();
          }}
          className="flex flex-col items-center gap-1"
          aria-label="Like"
        >
          <Heart
            size={28}
            className={cn(
              "transition-colors",
              liked ? "fill-accent text-accent" : "text-white"
            )}
          />
          <span className="text-xs font-semibold">
            {formatCount(likeCount)}
          </span>
        </button>

        <button
          onClick={(e) => {
            e.stopPropagation();
            setCommentsOpen(true);
          }}
          className="flex flex-col items-center gap-1"
          aria-label="Comments"
        >
          <MessageCircle size={28} />
          <span className="text-xs font-semibold">
            {formatCount(video.comments)}
          </span>
        </button>

        <button
          onClick={(e) => {
            e.stopPropagation();
            handleShare();
          }}
          className="flex flex-col items-center gap-1"
          aria-label="Share"
        >
          <Share2 size={26} />
          <span className="text-xs font-semibold">
            {formatCount(video.shares)}
          </span>
        </button>

        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleSave();
          }}
          className="flex flex-col items-center gap-1"
          aria-label="Save"
        >
          <Bookmark
            size={26}
            className={cn(saved && "fill-white text-white")}
          />
        </button>

        <button
          className="mt-1"
          aria-label="More"
          onClick={(e) => {
            e.stopPropagation();
            setMenuOpen(true);
          }}
        >
          <MoreHorizontal size={24} />
        </button>
      </div>

      <div className="absolute bottom-4 left-0 right-16 z-10 px-4">
        <Link
          href="/profile"
          onClick={(e) => e.stopPropagation()}
          className="mb-1 flex items-center gap-2"
        >
          <span className="font-semibold">@{user.username}</span>
          {user.verified && (
            <span className="rounded bg-accent px-1 text-[10px] font-bold">
              ✓
            </span>
          )}
          <span className="text-xs text-muted">
            · {timeAgo(video.createdAt)}
          </span>
        </Link>
        <p className="mb-1 line-clamp-2 text-sm leading-snug">
          {video.description}
        </p>
        <div className="flex flex-wrap gap-1.5">
          {video.hashtags.slice(0, 4).map((tag) => (
            <Link
              key={tag}
              href={`/tag/${tag}`}
              onClick={(e) => e.stopPropagation()}
              className="text-sm font-medium text-white/90 hover:underline"
            >
              #{tag}
            </Link>
          ))}
        </div>
      </div>

      
      {menuOpen && (
        <div className="fixed inset-0 z-[90] flex items-end justify-center">
          <div
            className="absolute inset-0 bg-black/60"
            onClick={(e) => {
              e.stopPropagation();
              setMenuOpen(false);
            }}
          />
          <div className="relative z-10 w-full max-w-lg rounded-t-2xl bg-card p-4 animate-fade-up">
            <button
              className="w-full rounded-xl py-3.5 text-left text-sm font-medium hover:bg-card-hover px-3"
              onClick={(e) => {
                e.stopPropagation();
                setMenuOpen(false);
                toast("Thanks — we'll review this", "info");
              }}
            >
              Report
            </button>
            <button
              className="w-full rounded-xl py-3.5 text-left text-sm font-medium hover:bg-card-hover px-3"
              onClick={(e) => {
                e.stopPropagation();
                setMenuOpen(false);
                toast("Not interested", "info");
              }}
            >
              Not interested
            </button>
            <button
              className="mt-1 w-full rounded-xl py-3.5 text-center text-sm font-semibold text-muted"
              onClick={(e) => {
                e.stopPropagation();
                setMenuOpen(false);
              }}
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      <CommentsSheet
        videoId={video.id}
        open={commentsOpen}
        onClose={() => setCommentsOpen(false)}
      />
    </div>
  );
}
