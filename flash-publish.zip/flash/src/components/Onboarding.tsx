"use client";

import { useState, useEffect } from "react";
import { Zap, Play, Heart, Upload, X } from "lucide-react";
import { hasSeenOnboarding, markOnboardingDone } from "@/lib/store";

const steps = [
  {
    icon: Play,
    title: "Swipe through Flashes",
    desc: "Scroll up and down to discover short videos tailored for you.",
  },
  {
    icon: Heart,
    title: "Double-tap to like",
    desc: "Like, comment, and share the moments that hit different.",
  },
  {
    icon: Upload,
    title: "Create in seconds",
    desc: "Upload a video, add a caption, and post your Flash to the world.",
  },
];

export default function Onboarding() {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState(0);

  useEffect(() => {
    if (!hasSeenOnboarding()) setOpen(true);
  }, []);

  if (!open) return null;

  const current = steps[step];
  const Icon = current.icon;
  const isLast = step === steps.length - 1;

  const finish = () => {
    markOnboardingDone();
    setOpen(false);
  };

  return (
    <div className="fixed inset-0 z-[250] flex items-end justify-center bg-black/80 backdrop-blur-sm sm:items-center">
      <div className="relative w-full max-w-md rounded-t-3xl bg-card p-6 sm:rounded-3xl animate-fade-up">
        <button
          onClick={finish}
          className="absolute right-4 top-4 text-muted hover:text-white"
          aria-label="Skip"
        >
          <X size={20} />
        </button>

        <div className="mb-6 flex justify-center">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-accent/15">
            <Icon size={32} className="text-accent" />
          </div>
        </div>

        <h2 className="mb-2 text-center text-xl font-bold">{current.title}</h2>
        <p className="mb-8 text-center text-sm leading-relaxed text-muted">
          {current.desc}
        </p>

        <div className="mb-6 flex justify-center gap-1.5">
          {steps.map((_, i) => (
            <div
              key={i}
              className={`h-1.5 rounded-full transition-all ${
                i === step ? "w-6 bg-accent" : "w-1.5 bg-white/20"
              }`}
            />
          ))}
        </div>

        <button
          onClick={() => (isLast ? finish() : setStep((s) => s + 1))}
          className="flex w-full items-center justify-center gap-2 rounded-full bg-accent py-3.5 font-semibold hover:bg-accent-hover"
        >
          {isLast ? (
            <>
              <Zap size={18} className="fill-white" />
              Start watching
            </>
          ) : (
            "Next"
          )}
        </button>
      </div>
    </div>
  );
}
