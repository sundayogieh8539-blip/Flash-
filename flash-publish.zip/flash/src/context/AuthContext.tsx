"use client";

import {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
  useCallback,
} from "react";
import { users, User } from "@/lib/data";
import { createClient, isSupabaseConfigured } from "@/lib/supabase/client";

interface AuthContextType {
  user: User | null;
  isLoggedIn: boolean;
  isLoading: boolean;
  isDemo: boolean;
  login: (username?: string) => void;
  loginWithEmail: (email: string, password: string) => Promise<{ error?: string }>;
  signUp: (email: string, password: string, username: string) => Promise<{ error?: string }>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);
const STORAGE_KEY = "flash_user";

function mapProfile(row: {
  id: string;
  username: string;
  display_name: string;
  avatar_url?: string | null;
  bio?: string | null;
  verified?: boolean;
}): User {
  return {
    id: row.id,
    username: row.username,
    displayName: row.display_name,
    avatar:
      row.avatar_url ||
      `https://api.dicebear.com/9.x/avataaars/svg?seed=${row.username}`,
    bio: row.bio || "",
    followers: 0,
    following: 0,
    likes: 0,
    verified: row.verified,
  };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const isDemo = !isSupabaseConfigured();

  useEffect(() => {
    let mounted = true;
    let unsubscribe: (() => void) | undefined;

    async function init() {
      if (isDemo) {
        try {
          const stored = localStorage.getItem(STORAGE_KEY);
          if (stored && mounted) setUser(JSON.parse(stored));
        } catch {
          // ignore
        }
        if (mounted) setIsLoading(false);
        return;
      }

      const supabase = createClient();
      if (!supabase) {
        if (mounted) setIsLoading(false);
        return;
      }

      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (session?.user && mounted) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("*")
          .eq("id", session.user.id)
          .single();
        if (profile) setUser(mapProfile(profile));
      }

      const {
        data: { subscription },
      } = supabase.auth.onAuthStateChange(async (_event, session) => {
        if (!mounted) return;
        if (session?.user) {
          const { data: profile } = await supabase
            .from("profiles")
            .select("*")
            .eq("id", session.user.id)
            .single();
          if (profile) setUser(mapProfile(profile));
        } else {
          setUser(null);
        }
      });

      unsubscribe = () => subscription.unsubscribe();
      if (mounted) setIsLoading(false);
    }

    init();

    return () => {
      mounted = false;
      unsubscribe?.();
    };
  }, [isDemo]);

  const login = useCallback((username?: string) => {
    const selected = users.find((u) => u.username === username) || users[0];
    setUser(selected);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(selected));
  }, []);

  const loginWithEmail = useCallback(async (email: string, password: string) => {
    const supabase = createClient();
    if (!supabase) return { error: "Supabase not configured" };
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) return { error: error.message };
    return {};
  }, []);

  const signUp = useCallback(
    async (email: string, password: string, username: string) => {
      const supabase = createClient();
      if (!supabase) return { error: "Supabase not configured" };
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: { username, display_name: username },
        },
      });
      if (error) return { error: error.message };
      return {};
    },
    []
  );

  const logout = useCallback(async () => {
    if (isDemo) {
      setUser(null);
      localStorage.removeItem(STORAGE_KEY);
      return;
    }
    const supabase = createClient();
    if (supabase) await supabase.auth.signOut();
    setUser(null);
  }, [isDemo]);

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoggedIn: !!user,
        isLoading,
        isDemo,
        login,
        loginWithEmail,
        signUp,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
