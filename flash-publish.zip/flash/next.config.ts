import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "images.unsplash.com" },
      { protocol: "https", hostname: "api.dicebear.com" },
      { protocol: "https", hostname: "commondatastorage.googleapis.com" },
      // Add your Supabase host after creating a project, e.g.:
      // { protocol: "https", hostname: "abcdefgh.supabase.co" },
    ],
  },
};

export default nextConfig;
